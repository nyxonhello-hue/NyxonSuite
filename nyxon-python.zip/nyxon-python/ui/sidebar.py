"""
Nyxon Automation Suite - Sidebar
Left navigation panel matching the design mockup.
"""

import customtkinter as ctk
from typing import Callable

NAV_ITEMS = [
    ("🏠", "Dashboard"),
    ("📁", "File Organizer"),
    ("🖥", "System Flush"),
    ("🌐", "Network Checker"),
    ("🚀", "Startup Manager"),
    ("⚙", "Settings"),
]

SIDEBAR_BG   = "#13111F"
ACTIVE_BG    = "#3B37A0"
HOVER_BG     = "#1E1B2E"
TEXT_COLOR   = "#C4C2D4"
ACTIVE_TEXT  = "#FFFFFF"
ACCENT       = "#7B5CF0"


class Sidebar(ctk.CTkFrame):
    """
    Fixed-width left sidebar with logo, nav items, and a system-status footer.
    Calls on_navigate(page_name) when the user clicks a nav item.
    """

    def __init__(self, parent, on_navigate: Callable[[str], None], **kwargs) -> None:
        super().__init__(
            parent,
            width=220,
            corner_radius=0,
            fg_color=SIDEBAR_BG,
            **kwargs,
        )
        self.grid_propagate(False)
        self._on_navigate = on_navigate
        self._active = "Dashboard"
        self._buttons: dict[str, ctk.CTkButton] = {}

        self._build()

    def _build(self) -> None:
        self.grid_rowconfigure(7, weight=1)   # push footer down

        # ── Logo ──────────────────────────────────────────────────────────────
        logo_frame = ctk.CTkFrame(self, fg_color="transparent", height=72)
        logo_frame.grid(row=0, column=0, sticky="ew", padx=18, pady=(18, 8))
        logo_frame.grid_propagate(False)

        ctk.CTkLabel(
            logo_frame,
            text="✕ NYXON",
            font=ctk.CTkFont(family="Segoe UI", size=18, weight="bold"),
            text_color=ACTIVE_TEXT,
            anchor="w",
        ).pack(anchor="w")

        ctk.CTkLabel(
            logo_frame,
            text="AUTOMATION SUITE",
            font=ctk.CTkFont(size=9, weight="bold"),
            text_color=ACCENT,
            anchor="w",
        ).pack(anchor="w")

        # ── Separator ─────────────────────────────────────────────────────────
        ctk.CTkFrame(self, height=1, fg_color="#2A2640").grid(
            row=1, column=0, sticky="ew", padx=14, pady=4
        )

        # ── Nav items ─────────────────────────────────────────────────────────
        for i, (icon, label) in enumerate(NAV_ITEMS):
            btn = ctk.CTkButton(
                self,
                text=f"  {icon}  {label}",
                anchor="w",
                height=40,
                corner_radius=8,
                border_spacing=6,
                fg_color=ACTIVE_BG if label == "Dashboard" else "transparent",
                hover_color=HOVER_BG,
                text_color=ACTIVE_TEXT if label == "Dashboard" else TEXT_COLOR,
                font=ctk.CTkFont(size=13),
                command=lambda l=label: self._on_click(l),
            )
            btn.grid(row=i + 2, column=0, sticky="ew", padx=10, pady=2)
            self._buttons[label] = btn

        # ── Footer: user info ─────────────────────────────────────────────────
        footer = ctk.CTkFrame(self, fg_color="#0E0C1A", corner_radius=10)
        footer.grid(row=8, column=0, sticky="ew", padx=10, pady=(0, 14))

        avatar = ctk.CTkLabel(
            footer,
            text="N",
            width=34,
            height=34,
            corner_radius=17,
            fg_color=ACCENT,
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color="white",
        )
        avatar.grid(row=0, column=0, padx=(10, 8), pady=10)

        info = ctk.CTkFrame(footer, fg_color="transparent")
        info.grid(row=0, column=1, sticky="w")

        ctk.CTkLabel(
            info,
            text="Nyxon User",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color=ACTIVE_TEXT,
            anchor="w",
        ).pack(anchor="w")

        ctk.CTkLabel(
            info,
            text="Pro",
            font=ctk.CTkFont(size=9, weight="bold"),
            text_color=ACCENT,
            fg_color="#1E1B2E",
            corner_radius=4,
            width=28,
            anchor="center",
        ).pack(anchor="w")

        ctk.CTkLabel(
            self,
            text="Nyxon Automation Suite v1.0.0",
            font=ctk.CTkFont(size=9),
            text_color="#4A475E",
        ).grid(row=9, column=0, pady=(0, 10))

    def _on_click(self, label: str) -> None:
        # Deactivate old
        if self._active in self._buttons:
            self._buttons[self._active].configure(
                fg_color="transparent", text_color=TEXT_COLOR
            )
        # Activate new
        self._active = label
        self._buttons[label].configure(fg_color=ACTIVE_BG, text_color=ACTIVE_TEXT)
        self._on_navigate(label)

    def set_active(self, label: str) -> None:
        self._on_click(label)
